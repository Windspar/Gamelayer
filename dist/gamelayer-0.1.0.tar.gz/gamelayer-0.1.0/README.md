GameLayer
=========
A pygame toolkit. Handles many different tools.
* Has two boiler plates.
* Has a few different image loaders
* Has gradient class.
* Has extend sprite class. Allow for quick rotation and movement.
* Has basic UI tools. Buttons, Labels, and TextLine.
* Has a grid, timer, wordwrap, color shortcut, and extend color class.

#### TODO ####
* Make more example.
* Make a pip package.

## Requirements ##
* Made in linux (Debian Buster Distro)
* Made in python 3.7
* pygame 1.9.6

### Credit ###
* Images by kenney - https://kenney.nl/
